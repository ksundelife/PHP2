<?php
define('ROOT_DIR', dirname(__DIR__));
define('DS', DIRECTORY_SEPARATOR);
define('CONTROLLER_NAMESPACE', "app\\controllers\\");
define('TEMPLATE_DIR', dirname(__DIR__) . "/views/");
define('PRODUCT_PER_PAGE', 2);