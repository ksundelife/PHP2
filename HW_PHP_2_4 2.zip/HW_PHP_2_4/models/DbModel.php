<?php


namespace app\models;


use app\engine\Db;

abstract class DbModel extends Model
{
    public static function getOne($id) {
        $tableName = static::getTableName();
        $sql = "SELECT * FROM {$tableName} WHERE id = :id";
        return Db::getInstance()->queryObject($sql, ["id" => $id], static::class);
    }

    public static function getLimit($page) {
        $tableName = static::getTableName();
        $sql = "SELECT * FROM {$tableName} LIMIT 0, :page";
        return Db::getInstance()->queryLimit($sql, $page);
    }

    public static function getAll() {
        $tableName = static::getTableName();
        $sql = "SELECT * FROM {$tableName}";
        return Db::getInstance()->queryAll($sql);

    }

    public function insert() {

        $params = [];
        $columns = [];

        foreach ($this->props as $key => $value) {
            $value = $this->$key;
            $params[":{$key}"] = $value;
            $columns[] = "`$key`";
        }
        var_dump($this->props);
        $columns = implode(", ", $columns);
        $values = implode(", ", array_keys($params));

        $tableName = static::getTableName();
        $sql = "INSERT INTO `{$tableName}`({$columns}) VALUES ($values)";
        Db::getInstance()->execute($sql, $params);
        $this->id = Db::getInstance()->lastInsertId();
    }
   
    public function update() {
    
        $params = [];
        $columns = [];

        foreach ($this->props as $key => $value) {
            if(!$value === true) continue;
            $params[":{$key}"] = $this->$key;;
            $columns[] = "`$key`". " = :$key";
            $this->props[$key] = false;
        }
        //var_dump($this->props);
        $columns = implode(", ", $columns);

        $tableName = static::getTableName();
        $sql = "UPDATE `{$tableName}` SET {$columns} WHERE id = :id";
        $params[':id'] = $this->id;
        var_dump($sql);
        Db::getInstance()->execute($sql, $params);
    }

    public function delete() {
        $tableName = static::getTableName();
        $sql = "DELETE FROM {$tableName} WHERE id = :id";
        return Db::getInstance()->execute($sql, [':id' => $this->id]);
    }

    public function save() {
        //TODO сделать фиксацию, чекнуть $this->id на null и вызвать insert или update
        //не поняла что такое "фиксация" но вроде получилось )))
        $params["id"] = $_POST['id'];
        var_dump($this->id);
        if(!$this->id){
            $this->insert();
        } else {
            $this->update();
        }
    }
}