<?php
//use app\models\{Product, User};
//use app\engine\Db;

include "../config/config.php";
include "../engine/Autoload.php";

use app\engine\Autoload;
use app\models\{Product, User};
use app\engine\Db;

spl_autoload_register([new Autoload(), 'loadClass']);


$controllerName = $_GET['c'] ?: 'product';
$actionName = $_GET['a'];

$controllerClass =  CONTROLLER_NAMESPACE . ucfirst($controllerName) . "Controller";

if (class_exists($controllerClass)) {
    $controller = new $controllerClass();
    $controller->runAction($actionName);
}



/** @var Product $product */

//CREATE

// $product = new Product("Диван Барон", "Прямой", 22000);
// var_dump($product);
// $product->save();

//UPDATE
// $product = Product::getOne(8);
// $product->name = "Диван Маруся";
// $product->price = "19000";
// $product->save();

// //DELETE
// $product = new Product();
// $product = $product->getOne(29);
// $product->delete();


die();

var_dump($product);

var_dump($product->getOne(1));

var_dump($product);


