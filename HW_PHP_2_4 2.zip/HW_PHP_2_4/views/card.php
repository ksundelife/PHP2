<h2>Карточка</h2>

<h3><a href="/?c=product&a=card&id=<?=$product->id?>"><?=$product->name?></a></h3>
<p><?=$product->description?></p>
<p><?=$product->price?></p>
<button>Купить</button>
<hr>
