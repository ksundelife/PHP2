<?php

include "../config/config.php";
include "../engine/Autoload.php";

use app\engine\Autoload;
use app\models\{Product, User};
use app\engine\Db;

spl_autoload_register([new Autoload(), 'loadClass']);

//CREATE

$product = new Product("Диван Мюнхен", "П-образный", 21000);
//$product->insert();
$user = new User("user4", "123d");
//$user->insert();

//DELETE

$product = new Product();
$product = $product->getOne(19);
//$product->delete();
$user = new User();
$user = $user->getOne(6);
//$user->delete();

//UPDATE

$product = new Product();
$product = $product->getOne(9);
$product->name = "Угловой диван Милан";
$product->description = "Универсальный";
var_dump($product);
//$product->update();





